import Vector3 from "./vector-3.js";

class Plane{
  constructor(A, B, C, D){
    
  }
  static fromABCD(A, B, C, D){
   
  }
  static fromABC(A, B, C, vector){
    
  }
  static fromThreeVectors(one, two, three){
    

  }
}

export default Plane;