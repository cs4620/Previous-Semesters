Camera module
=============

.. automodule:: Camera
   :members:
   :undoc-members:
   :show-inheritance:
