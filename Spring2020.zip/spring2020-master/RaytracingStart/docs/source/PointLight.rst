PointLight module
=================

.. automodule:: PointLight
   :members:
   :undoc-members:
   :show-inheritance:
