SpotLight module
================

.. automodule:: SpotLight
   :members:
   :undoc-members:
   :show-inheritance:
