Light module
============

.. automodule:: Light
   :members:
   :undoc-members:
   :show-inheritance:
