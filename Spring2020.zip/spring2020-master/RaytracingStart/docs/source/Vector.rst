Vector module
=============

.. automodule:: Vector
   :members:
   :undoc-members:
   :show-inheritance:
