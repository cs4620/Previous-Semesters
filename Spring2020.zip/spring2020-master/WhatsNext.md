# When will I use this?

## Even if its never...
I hope you see the world differently

## GPUs are everywhere
GPGPUs are on the rise
- On phones
- Used by the OS
- Used by office to render Word
- Used by MapBox
- Browser renders with the GPU

## Technical Artist Skills
- You may never use Blender again...
- But you will use graphics programs
- You may make graphics programs

# Ray Tracing
- You may never use.
- But some you may use comutational geometry
- You will move in and out of model-world-camera-screen space sometime somewhere.
