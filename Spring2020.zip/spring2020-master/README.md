# CSCI 4620 Spring 2020, unomaha.edu

This is the main repository for CSCI 4620 - Computer Graphics at unomaha.edu

This repo represents only half of the online content for this course. The other half, comprising mostly notes and assignments, on Canvas at unomaha.instructure.com. 

Other than a few backup notes in the LectureNotes folder, this repo is dedicated to the ray tracing code in RaytracingStart. More information is available in the README in that folder.

Released with an MIT license, B. Ricks, @bricksphd, 2020.

