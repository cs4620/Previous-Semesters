# 17I4620
CSCI 4620, 3D Graphics.

Course materials and code will be stored here.

# Course Notes
To see the course notes (live), click [here](https://1drv.ms/o/s!AmCUMqdaJyCSgb91UAJx9VDurhosRw)

Quick survey: https://www.surveymonkey.com/r/3D6SFBB
