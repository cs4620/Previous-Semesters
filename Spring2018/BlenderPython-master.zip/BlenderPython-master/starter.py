import bpy
import math

sce = bpy.context.scene
ob = bpy.context.object
i = 0

for f in range(sce.frame_start, sce.frame_end+1):
    sce.frame_set(f)
    ob.location.x = math.cos(i/10)
    ob.keyframe_insert(data_path="location")
    i = i + 1
