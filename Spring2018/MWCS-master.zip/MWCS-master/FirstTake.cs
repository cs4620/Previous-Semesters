using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FakeShader : MonoBehaviour {

    public List<GameObject> vertices; 


	// Use this for initialization
	void Start () {

        //Java for(:)
        foreach(var vertex in vertices)
        {
            Vector3 modelSpace = vertex.transform.position;
            Vector3 WorldSpace;
            Vector2 CameraSpace;
            Vector2 ScreenSpace;

            //Move the vertex into world space

            WorldSpace = modelSpace;

            //Move the vertex into camera space

            CameraSpace = new Vector2(WorldSpace.x, WorldSpace.y);

            //Move the vertex into screen space

          
            Vector3 CameraWithW = new Vector3(CameraSpace.x, CameraSpace.y, 0);

            Matrix4x4 ScreenTransform = Matrix4x4.identity;

            ScreenTransform.m03 = 3;
            ScreenTransform.m13 = -2;
            ScreenTransform.m00 = 180;
            ScreenTransform.m11 = -180;

            Vector3 ScreenTemp = ScreenTransform.MultiplyVector(CameraWithW);



            vertex.transform.Translate(new Vector3(ScreenTemp.x, ScreenTemp.y, 0));
            vertex.transform.localScale = new Vector3(100, 100, 100);
        }

		
	}
	
	
}
