Let's take a look at communication through images.

https://www.youtube.com/watch?v=4KYxkqlzyqM

