## Fundamental Problem in graphics

Speed and space

### Solution

Everything is a surface. A surface made of triangles.

## How to create surfaces made of triangles

In the real world the big programs are

- Film doing visual effects -> Autodesk Maya. Special Effects are what was in the original Star Wars. Visual Effects are computer generated.

- Games - >Autodesk 3DSMax.

No one uses blender in real life. Except us.

[Lambo Example](LamboPoliceCar.png)

[Lambo Example](LamboPoliceCar.blend)


## Outside Class

Follow along blender tutorials

Unity Tutorials
