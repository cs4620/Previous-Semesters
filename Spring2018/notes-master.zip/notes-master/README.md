# notes
Best viewed at https://4620.github.io/notes/

[Syllabus, etc.](https://github.com/4620/4620)

[Day 1](Day01.md)

[Day 2](Day02.md)

Day 3 - Modeling

Day 4 - Advanced Modeling

Day 5 - Animation

Day 6 - Rigging
