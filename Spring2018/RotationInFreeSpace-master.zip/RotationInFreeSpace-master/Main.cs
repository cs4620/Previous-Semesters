using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {

   


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        float yaw = Input.GetAxis("Horizontal");
        float pitch = Input.GetAxis("Vertical");

        transform.Rotate(pitch, yaw, 0);

        //transform.position += new Vector3(0, 0, Time.deltaTime * 1);
        //transform.Translate(0, 0, Time.deltaTime * 1);
        //transform.position += transform.forward * Time.deltaTime * 1;
	}
}
