using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Baddie : MonoBehaviour {

    public Main main;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        Vector3 myPosition = transform.position;
        Vector3 theirPostion = main.transform.position;
        Vector3 localOffsetInWorldSpace = myPosition - theirPostion;
        Vector3 toThemInWorldSpaceNormalized = localOffsetInWorldSpace.normalized;
        Vector3 myForwardInWorldSpace = transform.forward;

        Vector3 toRotateAbout = Vector3.Cross(myForwardInWorldSpace, toThemInWorldSpaceNormalized);

        float roationAmount = Time.deltaTime * 25f;

        Quaternion q = Quaternion.AngleAxis(roationAmount, toRotateAbout);

        transform.Rotate(q.eulerAngles);

        transform.position += transform.forward * Time.deltaTime * 1;
		
	}
}
