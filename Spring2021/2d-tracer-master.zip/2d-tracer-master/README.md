# ps

Include canvas.js in your .html file, and it will bootstrap a canvas and accompanying update() and draw() functions. It is left to the developer to only add a customUpdate() and customDraw() methods to have realtime (potentially interactive) visualization in a webpage. See index.html for an example of how to include ps.js and how to add the custom methods.

You can include canvas.js from rawgit.com via https://rawgit.com/bricksSeeds/ps/master/canvas.js
