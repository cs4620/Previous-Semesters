public class PureReflective implements Material{
  
  public PureReflective(){
    
  }
  public Vector3 Shade(Vector3 fromDirection, Vector3 position, Vector3 normal, DirectionalLight directionalLight, Scene scene, int remainingBounces){
   
    return Vector3.Zero;
  }

  
  
}
