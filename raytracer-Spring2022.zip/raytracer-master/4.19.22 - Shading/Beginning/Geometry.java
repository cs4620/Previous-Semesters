public interface Geometry {

  Intersection intersect(Ray ray);
  
}
